module app {
	
	requires service;
}