package ex2_datatype;

public class Ex1_Integer {
	public static void main(String[] args) {
		int var1 = 0b1011; //2진수 11;
		int var2 = 0206; //8진수 134
		int var3 = 365; //10진수
		int var4 = 0xB3; //16진수
		//0~9A~F
		
		System.out.println("var1 : " + var1);
		System.out.println("var2 : " + var2);
		System.out.println("var3 : " + var3);
		System.out.println("var4 : " + var4);
		
		
		
	}

}
