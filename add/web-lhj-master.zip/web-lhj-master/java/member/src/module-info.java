module member {
	exports member;
}